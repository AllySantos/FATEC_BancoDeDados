package com.edu.WebServiceAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebServiceApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebServiceApiApplication.class, args);
	}

}
