package com.edu.WebServiceAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebServiceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
